hai bye
hai hello
bye bye
